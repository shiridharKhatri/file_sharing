"use client"

import { useState, useEffect, useRef } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { shareAPI } from "../services/api"
import { useShare } from "../context/ShareContext"
import {
  Lock,
  Eye,
  Users,
  Clock,
  AlertCircle,
  Loader2,
  ArrowLeft,
  Edit3,
  EyeIcon,
  Download,
  Copy,
  Share2,
  Globe,
  Wifi,
  Shield,
  Settings,
  Moon,
  Sun,
  Palette,
  X,
  Upload,
  File,
  Plus,
  ImageIcon,
} from "lucide-react"
import { getFileIcon } from "../utils/helpers"
import "./ShareViewer.css"

export default function ShareViewer() {
  const { shareId } = useParams()
  const navigate = useNavigate()
  const {
    joinShare,
    share,
    connected,
    activeUsers,
    typingUsers,
    updateText,
    setTyping,
    uploadFiles,
    deleteFile,
    files,
  } = useShare()

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [requiresPassword, setRequiresPassword] = useState(false)
  const [password, setPassword] = useState("")
  const [shareData, setShareData] = useState(null)
  const [isEditing, setIsEditing] = useState(false)
  const [localText, setLocalText] = useState("")
  const [hasJoined, setHasJoined] = useState(false)
  const [passwordError, setPasswordError] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [theme, setTheme] = useState("dark")
  const [showSettings, setShowSettings] = useState(false)
  const [showUploadMenu, setShowUploadMenu] = useState(false)
  const [notification, setNotification] = useState(null)

  const fileInputRef = useRef(null)
  const uploadMenuRef = useRef(null)

  useEffect(() => {
    if (shareId) {
      console.log("ShareViewer: Loading share with ID:", shareId)
      loadShare(shareId)
    } else {
      console.error("ShareViewer: No shareId provided")
      setError("No share ID provided")
      setLoading(false)
    }
  }, [shareId])

  useEffect(() => {
    // Update local text when share content changes (from other users)
    if (share && share.textContent !== undefined && hasJoined) {
      if (share.textContent !== localText && !window.textUpdateTimeout) {
        console.log("Viewer received text update from other user")
        setLocalText(share.textContent)
      }
    }
  }, [share, hasJoined])

  useEffect(() => {
    // Auto-join the share when connected and share data is loaded
    if (connected && shareData && !hasJoined && !requiresPassword) {
      console.log("Auto-joining share for real-time updates")
      joinShare(shareId, "Viewer")
      setHasJoined(true)
    }
  }, [connected, shareData, shareId, hasJoined, requiresPassword])

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme)
  }, [theme])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (uploadMenuRef.current && !uploadMenuRef.current.contains(event.target)) {
        setShowUploadMenu(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const showNotification = (message, type = "success") => {
    setNotification({ message, type })
    setTimeout(() => setNotification(null), 3000)
  }

  const loadShare = async (id, pwd = null) => {
    try {
      setLoading(true)
      setError(null)
      setPasswordError("")

      console.log("ShareViewer: Loading share:", id, pwd ? "with password" : "without password")

      // Add timeout to prevent infinite loading
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Request timeout - share may not exist")), 10000),
      )

      const apiPromise = shareAPI.get(id, pwd)
      const response = await Promise.race([apiPromise, timeoutPromise])

      console.log("ShareViewer: Share loaded successfully:", response.data)

      // Handle both response formats
      const data = response.data.data || response.data
      console.log("ShareViewer: Processed share data:", data)

      if (!data) {
        throw new Error("No share data received from server")
      }

      setShareData(data)
      setLocalText(data.textContent || "")
      setRequiresPassword(false)
      setIsSubmitting(false)
      setLoading(false)
    } catch (error) {
      console.error("ShareViewer: Error loading share:", error)
      setIsSubmitting(false)

      // Handle network restriction errors specifically
      if (error.message && error.message.includes("local network")) {
        setError(
          "This collaborative share is restricted to local network users only. Please ensure you're connected to the same network as the share creator.",
        )
        setLoading(false)
        return
      }

      if (error.status === 401 && (error.data?.requiresPassword || error.message.includes("Password"))) {
        console.log("ShareViewer: Password required")
        setRequiresPassword(true)
        setPasswordError("Invalid password. Please try again.")
        setLoading(false)
      } else if (error.status === 404 || error.message.includes("not found")) {
        console.log("ShareViewer: Share not found")
        setError("Share not found. It may have expired or the link is invalid.")
        setLoading(false)
      } else if (error.message.includes("timeout")) {
        console.log("ShareViewer: Request timeout")
        setError("Request timeout. Please check your connection and try again.")
        setLoading(false)
      } else {
        console.log("ShareViewer: General error:", error.message)
        setError(error.message || "Failed to load share. Please try again.")
        setLoading(false)
      }
    }
  }

  const handlePasswordSubmit = async (e) => {
    e.preventDefault()

    // Clear previous errors
    setPasswordError("")

    // Validate password
    if (!password.trim()) {
      setPasswordError("Password is required")
      return
    }

    setIsSubmitting(true)

    try {
      console.log("ShareViewer: Submitting password for share access")
      await loadShare(shareId, password.trim())
      // If successful, loadShare will handle setting the states
    } catch (error) {
      console.error("ShareViewer: Password submission error:", error)
      setPasswordError("Invalid password. Please try again.")
      setIsSubmitting(false)
    }
  }

  const handleTextChange = (newText) => {
    setLocalText(newText)

    if (shareData && shareData.settings?.allowEdit && connected && hasJoined) {
      // Send typing indicator
      setTyping(shareId, true)

      // Clear existing timeout
      if (window.textUpdateTimeout) {
        clearTimeout(window.textUpdateTimeout)
      }

      // Debounce the actual update
      window.textUpdateTimeout = setTimeout(() => {
        console.log("Sending text update from viewer")
        updateText(shareId, newText, shareData.language)
        setTyping(shareId, false)
        window.textUpdateTimeout = null
      }, 1000)
    }
  }

  const addFiles = async (newFiles) => {
    if (!shareId || !hasJoined) {
      showNotification("Please wait for connection to be established", "error")
      return
    }

    if (!newFiles || newFiles.length === 0) {
      showNotification("No files selected", "error")
      return
    }

    try {
      console.log("Adding files to share:", shareId, newFiles)
      await uploadFiles(shareId, newFiles)
      setShowUploadMenu(false)
      showNotification(`${newFiles.length} file(s) uploaded successfully`)
    } catch (error) {
      console.error("File upload failed:", error)
      showNotification("Failed to upload files", "error")
    }
  }

  const removeFile = async (fileId) => {
    try {
      await deleteFile(fileId)
      showNotification("File removed")
    } catch (error) {
      showNotification("Failed to remove file", "error")
    }
  }

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
    showNotification("Copied to clipboard!")
  }

  const downloadContent = () => {
    const element = document.createElement("a")
    const file = new Blob([localText], { type: "text/plain" })
    element.href = URL.createObjectURL(file)
    element.download = `${shareData?.title || "shared-content"}.txt`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
    showNotification("Content downloaded!")
  }

  const getModeConfig = () => {
    const modes = {
      global: { label: "Public", icon: Globe, color: "#0ea5e9" },
      collaborative: { label: "Collaborative", icon: Wifi, color: "#059669" },
      private: { label: "Private", icon: Shield, color: "#7c3aed" },
    }
    return modes[shareData?.mode] || modes.private
  }

  const themes = [
    { id: "dark", name: "Dark", icon: Moon },
    { id: "light", name: "Light", icon: Sun },
    { id: "auto", name: "Auto", icon: Palette },
  ]

  // Show loading screen
  if (loading) {
    return (
      <div className="share-viewer">
        <div className="loading-container">
          <div className="loading-content">
            <div className="loading-spinner-wrapper">
              <Loader2 className="loading-spinner" />
            </div>
            <h3 className="loading-title">Loading Share</h3>
            <p className="loading-text">Fetching shared content for ID: {shareId}</p>
            <button onClick={() => navigate("/")} className="loading-cancel-btn" style={{ marginTop: "16px" }}>
              Cancel & Go Home
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Show error screen
  if (error) {
    return (
      <div className="share-viewer">
        <div className="error-container">
          <div className="error-content">
            <div className="error-icon-wrapper">
              <AlertCircle className="error-icon" />
            </div>
            <h1 className="error-title">Share Not Available</h1>
            <p className="error-message">{error}</p>
            <div className="error-actions">
              <button onClick={() => navigate("/")} className="error-button">
                <ArrowLeft size={16} />
                Go Home
              </button>
              <button onClick={() => loadShare(shareId)} className="error-button secondary">
                <Loader2 size={16} />
                Try Again
              </button>
            </div>
            <div className="error-help">
              <p>
                Share ID: <code>{shareId}</code>
              </p>
              <p>If this is a private share, make sure you have the correct link.</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Show password screen
  if (requiresPassword) {
    return (
      <div className="share-viewer">
        <div className="password-container">
          <div className="password-modal">
            <div className="password-header">
              <div className="password-icon-wrapper">
                <Lock className="password-icon" />
              </div>
              <h1 className="password-title">Protected Share</h1>
              <p className="password-subtitle">This share is password protected</p>
            </div>

            <form onSubmit={handlePasswordSubmit} className="password-form">
              <div className="password-field">
                <label className="password-label">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value)
                    setPasswordError("") // Clear error when user types
                  }}
                  className={`password-input ${passwordError ? "error" : ""}`}
                  placeholder="Enter password..."
                  required
                  autoFocus
                  disabled={isSubmitting}
                />
                {passwordError && <div className="password-error">{passwordError}</div>}
              </div>

              <button type="submit" className="password-submit" disabled={isSubmitting || !password.trim()}>
                {isSubmitting ? (
                  <>
                    <Loader2 size={16} className="spinning" />
                    Verifying...
                  </>
                ) : (
                  <>
                    <Lock size={16} />
                    Access Share
                  </>
                )}
              </button>
            </form>

            <button onClick={() => navigate("/")} className="password-back">
              ← Back to Home
            </button>
          </div>
        </div>
      </div>
    )
  }

  const canEdit =
    shareData?.settings?.allowEdit &&
    (shareData?.mode === "global" || shareData?.mode === "collaborative" || shareData?.mode === "private")

  const modeConfig = getModeConfig()
  const IconComponent = modeConfig.icon

  // Combine files from shareData and real-time files
  const allFiles = [...(shareData?.files || []), ...files]

  return (
    <div className="share-viewer app" data-theme={theme}>
      {/* Notification */}
      {notification && (
        <div className={`notification ${notification.type}`}>
          <div className="notification-content">
            {notification.type === "success" ? <Eye size={16} /> : <AlertCircle size={16} />}
            <span>{notification.message}</span>
          </div>
        </div>
      )}

      {/* Header - Matching Main App Layout */}
      <header className="header">
        <div className="header-left">
          <div className="brand">
            <button onClick={() => navigate("/")} className="logo-back-btn">
              <Share2 size={20} />
            </button>
            <div className="brand-text">
              <h1>Shareee.me</h1>
              <span>Real-time Collaboration</span>
            </div>
          </div>

          <div className="mode-display">
            <div className="mode-btn active" style={{ "--mode-color": modeConfig.color }}>
              <IconComponent size={16} />
              <span>{modeConfig.label}</span>
            </div>
          </div>
        </div>

        <div className="header-right">
          <div className="file-section">
            {allFiles.length > 0 && (
              <div className="file-chips">
                {allFiles.slice(0, 3).map((file) => {
                  const FileIconComponent = getFileIcon(file.mimetype || "application/octet-stream")
                  return (
                    <div key={file._id || file.id} className="file-chip">
                      <FileIconComponent size={12} />
                      <span>{file.originalName}</span>
                      <button onClick={() => removeFile(file._id || file.id)}>
                        <X size={10} />
                      </button>
                    </div>
                  )
                })}
                {allFiles.length > 3 && <div className="file-chip more">+{allFiles.length - 3}</div>}
              </div>
            )}

            <div className="upload-section" ref={uploadMenuRef}>
              <button
                className="upload-btn"
                onClick={() => setShowUploadMenu(!showUploadMenu)}
                disabled={!hasJoined}
                title={!hasJoined ? "Connecting to share..." : "Upload files"}
              >
                <Upload size={16} />
                <span>Upload</span>
              </button>

              {showUploadMenu && (
                <div className="upload-menu">
                  <button onClick={() => fileInputRef.current?.click()}>
                    <File size={14} />
                    <span>Browse Files</span>
                  </button>
                  <button onClick={() => fileInputRef.current?.click()}>
                    <ImageIcon size={14} />
                    <span>Upload Photos</span>
                  </button>
                  <button onClick={() => fileInputRef.current?.click()}>
                    <Plus size={14} />
                    <span>Add Multiple</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="header-actions">
            {/* Active Users Indicator */}
            {activeUsers > 0 && hasJoined && (
              <div className="active-users">
                <Users size={14} />
                <span>{activeUsers}</span>
              </div>
            )}

            {/* Views Counter */}
            <div className="sharing-status">
              <Eye size={14} />
              <span>{shareData?.stats?.views || 0} views</span>
            </div>

            {/* Expiry Info */}
            <div className="sharing-status">
              <Clock size={14} />
              <span>Expires {new Date(shareData?.expiresAt).toLocaleDateString()}</span>
            </div>

            {/* Connection Status */}
            {!connected && (
              <div className="sharing-status" style={{ color: "#d29922" }}>
                <Loader2 size={14} className="spinning" />
                <span>Connecting...</span>
              </div>
            )}

            <div className="theme-selector">
              {themes.map((themeOption) => {
                const ThemeIconComponent = themeOption.icon
                return (
                  <button
                    key={themeOption.id}
                    className={`theme-btn ${theme === themeOption.id ? "active" : ""}`}
                    onClick={() => setTheme(themeOption.id)}
                    title={themeOption.name}
                  >
                    <ThemeIconComponent size={14} />
                  </button>
                )
              })}
            </div>
            <button className="icon-btn" onClick={() => setShowSettings(true)}>
              <Settings size={16} />
            </button>
          </div>
        </div>
      </header>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="*/*"
        onChange={(e) => addFiles(e.target.files)}
        style={{ display: "none" }}
      />

      {/* Editor Container */}
      <main className="editor-container">
        <div className="editor-header">
          <div className="editor-info">
            <div className="language-indicator">
              <span>{shareData?.language || "plaintext"}</span>
            </div>
            <div className="editor-stats">
              <span>{localText.length} chars</span>
              <span>{localText.split("\n").length} lines</span>
              <span>{localText.split(/\s+/).filter((w) => w).length} words</span>
            </div>
            {/* Typing Indicators */}
            {typingUsers.length > 0 && (
              <div className="typing-indicators">
                {typingUsers.map((user) => (
                  <span key={user.socketId} className="typing-user">
                    {user.username} is typing...
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="editor-actions">
            {localText && (
              <>
                <button className="action-btn" onClick={() => copyToClipboard(localText)}>
                  <Copy size={14} />
                  <span>Copy</span>
                </button>
                <button className="action-btn" onClick={downloadContent}>
                  <Download size={14} />
                  <span>Download</span>
                </button>
              </>
            )}
            {canEdit && (
              <button className={`action-btn ${isEditing ? "active" : ""}`} onClick={() => setIsEditing(!isEditing)}>
                {isEditing ? <EyeIcon size={14} /> : <Edit3 size={14} />}
                <span>{isEditing ? "View" : "Edit"}</span>
              </button>
            )}
          </div>
        </div>

        <div className="editor-wrapper">
          <div className="line-numbers">
            {localText.split("\n").map((_, index) => (
              <div key={index} className="line-number">
                {index + 1}
              </div>
            ))}
          </div>

          {canEdit && isEditing ? (
            <textarea
              className="code-editor"
              value={localText}
              onChange={(e) => handleTextChange(e.target.value)}
              placeholder="Start editing the shared content..."
              spellCheck={false}
            />
          ) : (
            <pre className="code-editor readonly">
              {localText || <span className="placeholder-text">No content available</span>}
            </pre>
          )}
        </div>
      </main>

      {/* Footer - Matching Main App */}
      <footer className="footer">
        <div className="footer-left">
          <div className="mode-info">
            <div className="mode-indicator" style={{ backgroundColor: modeConfig.color }}>
              <IconComponent size={12} />
            </div>
            <span>{shareData?.title || "Shared Document"}</span>
            {connected && <span className="status connected">Connected</span>}
            {!connected && <span className="status disconnected">Disconnected</span>}
          </div>
        </div>

        <div className="footer-center">
          {shareData?.mode === "private" && (
            <div className="mode-description">
              <Lock size={12} />
              <span>Password protected link</span>
              <span className="status connected">CONNECTED</span>
            </div>
          )}
          {allFiles.length > 0 && (
            <div className="mode-description">
              <File size={12} />
              <span>{allFiles.length} files attached</span>
              <span style={{ fontSize: "10px", color: "#8b949e" }}>Auto-delete in 12h</span>
            </div>
          )}
        </div>

        <div className="footer-right">
          <div className="share-result">
            <span>Share ID: {shareId}</span>
          </div>
        </div>
      </footer>

      {/* Files Section */}
      {allFiles.length > 0 && (
        <div className="files-overlay">
          <div className="files-section">
            <h3 className="files-title">Attached Files ({allFiles.length})</h3>
            <div className="files-list">
              {allFiles.map((file) => {
                const FileIconComponent = getFileIcon(file.mimetype || "application/octet-stream")
                return (
                  <div key={file._id || file.id} className="file-item">
                    <div className="file-info">
                      <div className="file-icon">
                        <FileIconComponent size={16} />
                      </div>
                      <div className="file-details">
                        <p className="file-name">{file.originalName}</p>
                        <p className="file-size">{((file.size || 0) / 1024).toFixed(1)} KB</p>
                        <p className="file-expiry">Auto-delete in 12 hours</p>
                      </div>
                    </div>
                    <div className="file-actions">
                      <a
                        href={`http://localhost:5000/api/files/download/${file._id || file.id}`}
                        className="file-download"
                        download
                      >
                        <Download size={12} />
                      </a>
                      <button className="file-delete" onClick={() => removeFile(file._id || file.id)}>
                        <X size={12} />
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div className="settings-overlay" onClick={() => setShowSettings(false)}>
          <div className="settings-modal" onClick={(e) => e.stopPropagation()}>
            <div className="settings-header">
              <h3>ShareViewer Settings</h3>
              <button onClick={() => setShowSettings(false)}>
                <X size={16} />
              </button>
            </div>

            <div className="settings-content">
              <div className="setting-group">
                <h4>Share Information</h4>
                <div className="setting-item">
                  <label>
                    <span>Share ID</span>
                    <span style={{ fontSize: "11px", color: "#8b949e" }}>{shareId}</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Mode</span>
                    <span style={{ color: modeConfig.color, fontWeight: 600 }}>{modeConfig.label}</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Status</span>
                    <span className={`status ${connected ? "connected" : "disconnected"}`}>
                      {connected ? "Connected" : "Disconnected"}
                    </span>
                  </label>
                </div>
              </div>

              <div className="setting-group">
                <h4>Files & Storage</h4>
                <div className="setting-item">
                  <label>
                    <span>Attached Files</span>
                    <span>{allFiles.length}</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Auto-Delete</span>
                    <span style={{ color: "#d29922" }}>12 hours</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Upload Status</span>
                    <span className={`status ${hasJoined ? "connected" : "disconnected"}`}>
                      {hasJoined ? "Ready" : "Connecting"}
                    </span>
                  </label>
                </div>
              </div>

              <div className="setting-group">
                <h4>Content</h4>
                <div className="setting-item">
                  <label>
                    <span>Language</span>
                    <span>{shareData?.language || "plaintext"}</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Characters</span>
                    <span>{localText.length}</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Lines</span>
                    <span>{localText.split("\n").length}</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Words</span>
                    <span>{localText.split(/\s+/).filter((w) => w).length}</span>
                  </label>
                </div>
              </div>

              <div className="setting-group">
                <h4>Permissions</h4>
                <div className="setting-item">
                  <label>
                    <span>Can Edit</span>
                    <span className={`status ${canEdit ? "connected" : "disconnected"}`}>{canEdit ? "Yes" : "No"}</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Can Upload</span>
                    <span className="status connected">Yes</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Can Download</span>
                    <span className="status connected">Yes</span>
                  </label>
                </div>
              </div>

              <div className="setting-group">
                <h4>Statistics</h4>
                <div className="setting-item">
                  <label>
                    <span>Views</span>
                    <span>{shareData?.stats?.views || 0}</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Active Users</span>
                    <span>{activeUsers}</span>
                  </label>
                </div>
                <div className="setting-item">
                  <label>
                    <span>Expires</span>
                    <span>{new Date(shareData?.expiresAt).toLocaleDateString()}</span>
                  </label>
                </div>
              </div>

              <div className="setting-group">
                <h4>Theme</h4>
                <div className="setting-item">
                  <label>
                    <span>Current Theme</span>
                    <select value={theme} onChange={(e) => setTheme(e.target.value)}>
                      <option value="dark">Dark</option>
                      <option value="light">Light</option>
                      <option value="auto">Auto</option>
                    </select>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
